import json
import sys

for index, filename in enumerate(sys.argv[1:]):
    with open(filename) as stream:
        data = json.load(stream)
    cases = data['comparisons']
    matches = sum(case['results'] == data['full'] for case in cases.values())
    diffs = []
    for case in cases.values():
        for rid, result in case['results'].items():
            reference = data['full'][rid]
            for field in ('prompt_logprobs', 'generated_logprobs'):
                assert len(result[field]) == len(reference[field])
                diffs.extend(abs(a-b) for a, b in zip(result[field], reference[field]) if a != b)
    print(filename, 'exact cases', matches, '/', len(cases),
          'different logprobs', len(diffs), 'max difference', max(diffs, default=0))
    assert (matches == len(cases)) == (index == 1)
