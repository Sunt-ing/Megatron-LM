# MLA request-arrival reproduction

Use a disposable directory on an H200 with Python 3.12.3, PyTorch
2.11.0a0+eb65b36914.nv26.02 (CUDA 13.1), Transformer Engine 2.18.0,
flash-attn-4 4.0.0b35 and Transformers 5.19.0. The model needs about 38 GB
of allocated GPU memory in this configuration. These are the measured runtime
versions; this document does not claim a fresh-container build was tested.

Install the Megatron inference/test dependencies in that environment. The
additional Python packages used for Bridge are pinned in requirements-runtime.txt:
`python -m pip install -r requirements-runtime.txt`. Keep the listed PyTorch/TE/FA4 versions. The following
commands provide the exact source dependencies; FlashMLA must be built against
the same PyTorch/CUDA environment.

```bash
export REPRO_DIR="$PWD"
git clone https://github.com/NVIDIA/Megatron-Bridge.git bridge
git -C bridge checkout 76cf8ca3402c3fb28465bcc9ef5fbb58d92181bc
git clone --recursive https://github.com/deepseek-ai/FlashMLA.git flashmla
git -C flashmla checkout b7643bd54521f563b839b98289b5cd048c062ba2
git -C flashmla submodule update --init --recursive
(cd flashmla && python setup.py build_ext --inplace)
git clone https://github.com/NVIDIA/Megatron-LM.git baseline
git -C baseline checkout ce852bfb93f364f64a556602fc71a5d9ed2c377e
git clone --no-local baseline candidate
git -C candidate apply "$REPRO_DIR/external-change.patch"
git clone --no-local baseline reverted
git -C reverted apply "$REPRO_DIR/external-change.patch"
git -C reverted restore --source=HEAD -- megatron/core/transformer/attention.py megatron/core/transformer/multi_latent_attention.py

export MODEL_PATH="$REPRO_DIR/Moonlight-16B-A3B"
python - <<'MODEL'
import os
from huggingface_hub import snapshot_download
snapshot_download("moonshotai/Moonlight-16B-A3B",
    revision="476b36a473d4467f94469414bef6cee75c9c8172",
    local_dir=os.environ["MODEL_PATH"])
MODEL

export NCCL_NVLS_ENABLE=0 CUBLASLT_WORKSPACE_SIZE=0 HF_HUB_OFFLINE=1
for variant in baseline candidate reverted; do
  export PYTHONPATH="$REPRO_DIR/flashmla:$REPRO_DIR/$variant:$REPRO_DIR/bridge/src"
  export MEASUREMENT_OUTPUT="$REPRO_DIR/$variant.json"
  (cd "$REPRO_DIR/$variant" &&
    python -m torch.distributed.run --standalone --nproc_per_node=1 "$REPRO_DIR/reproduce.py")
done
python compare.py baseline.json candidate.json reverted.json
```

Place the patch beside this README before running. The script reads MODEL_PATH
and MEASUREMENT_OUTPUT; no internal model store or service is needed. It loads
pretrained BF16 weights, checks checkpoint tensors, and uses four text prompts,
greedy sampling, TP1/PP1, a 2 GiB latent cache and three repeats per arrival order.
Eight tokens are generated per request. For the longer measurement, substitute
reproduce64.py for reproduce.py. Model execution is eager.

The script writes matching and mismatching results without aborting. compare.py
enforces the expected before/fix/revert result: original and reverted runs must
differ from solo; the candidate must match exactly. It compares raw results,
not saved equality flags.

The archived timing runs used baseline b607c1b7f564f47dbb9f1b962e9c91f40abd8c59.
The final causal run uses candidate 9367dd0f7d58ca27860df4c38b39028fbec04b2b,
based on ce852bfb93f364f64a556602fc71a5d9ed2c377e. Only the two production
attention files were restored for its reverted control.

Additional small-model controls, using the same environment:

```bash
export PYTHONPATH="$REPRO_DIR/flashmla:$REPRO_DIR/candidate:$REPRO_DIR/bridge/src"
(cd candidate && python -m torch.distributed.run --standalone --nproc_per_node=1 "$REPRO_DIR/graph_control.py")
for variant in baseline candidate; do
  export PYTHONPATH="$REPRO_DIR/flashmla:$REPRO_DIR/$variant:$REPRO_DIR/bridge/src"
  export COMPAT_OUTPUT="$REPRO_DIR/normal-$variant.json"
  (cd "$variant" && python -m torch.distributed.run --standalone --nproc_per_node=1 "$REPRO_DIR/normal_control.py")
done
python - <<'COMPARE'
import json
assert json.load(open('normal-baseline.json')) == json.load(open('normal-candidate.json'))
COMPARE
```

The graph script requires actual replay and exact solo/arrival output equality.
The normal control compares the unchanged non-batch-invariant behavior, using
prompt lengths supported by the baseline FA4 SM90 implementation.

Raw JSON values are unchanged. Logs replace private workspace prefixes,
mount details and machine names with placeholders; numerical output and error messages are
unchanged. The graph log is a small-model control, not a pretrained Moonlight
graph measurement. The patch's repository regression needs no model download.
