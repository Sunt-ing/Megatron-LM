"""Pretrained Moonlight arrival timing and memory comparison."""
import gc
import os
import time
import json
from pathlib import Path

import torch

from tests.unit_tests.models.test_gpt_model_batch_invariant import (
    DummyTokenizer,
    DynamicInferenceContext,
    DynamicInferenceEngine,
    Float16Module,
    GPTInferenceWrapper,
    InferenceConfig,
    SamplingParams,
    TextGenerationController,
    Utils,
    AttnBackend,
    GPTModel,
    TransformerConfig,
    _BIK_FA_VERSION,
    _configure_flash_attention_env,
    get_gpt_layer_with_transformer_engine_spec,
    model_parallel_cuda_manual_seed,
    set_batch_invariant_mode,
    te_supports_batch_invariant_attention,
)


def main():
    from megatron.core.transformer.transformer_config import MLATransformerConfig
    from megatron.core.transformer import attention as attention_module
    assert te_supports_batch_invariant_attention()
    Utils.initialize_model_parallel(1, 1)
    _configure_flash_attention_env()
    torch.manual_seed(321)
    model_parallel_cuda_manual_seed(321)
    from megatron.bridge import AutoBridge
    from transformers import AutoTokenizer
    from safetensors import safe_open
    model_path = Path(os.environ['MODEL_PATH'])
    bridge = AutoBridge.from_hf_pretrained(str(model_path))
    provider = bridge.to_megatron_provider(load_weights=True)
    provider.tensor_model_parallel_size = 1
    provider.pipeline_model_parallel_size = 1
    provider.sequence_parallel = False
    provider.params_dtype = torch.bfloat16
    provider.bf16 = True
    provider.fp16 = False
    provider.use_cpu_initialization = False
    provider.cache_mla_latents = True
    provider.apply_rope_fusion = False
    provider.batch_invariant_mode = True
    provider.batch_invariant_backend = 'te_native'
    provider.attention_backend = AttnBackend.flash
    provider.flash_attention_version = 4
    provider.hidden_dropout = 0.0
    provider.attention_dropout = 0.0
    provider.cuda_graph_impl = 'none'
    provider.moe_grouped_gemm = True
    provider.moe_token_dispatcher_type = 'alltoall'
    provider.moe_permute_fusion = False
    provider.moe_router_fusion = False
    assert not provider.perform_initialization and provider.pre_wrap_hook is not None
    provider.finalize()
    models = provider.provide_distributed_model(wrap_with_ddp=False)
    assert len(models) == 1
    model = models[0].cuda().eval()
    base = model.module if isinstance(model, Float16Module) else model
    assert base.config.cache_mla_latents and base.config.params_dtype == torch.bfloat16
    assert not base.config.fp8 and not base.config.fp4
    index = json.loads((model_path / 'model.safetensors.index.json').read_text())['weight_map']
    for key, actual in [('model.norm.weight', base.decoder.final_layernorm.weight),
                        ('model.embed_tokens.weight', base.embedding.word_embeddings.weight),
                        ('model.layers.0.self_attn.kv_a_proj_with_mqa.weight',
                         base.decoder.layers[0].self_attention.linear_kv_down_proj.weight)]:
        with safe_open(str(model_path / index[key]), framework='pt') as f:
            expected = f.get_tensor(key)
            assert torch.equal(actual.detach().cpu()[:expected.shape[0]], expected.to(actual.dtype)), key
    tokenizer_hf = AutoTokenizer.from_pretrained(str(model_path))
    tokenizer = DummyTokenizer(vocab_size=tokenizer_hf.vocab_size, eod=tokenizer_hf.eos_token_id)
    texts = ['Explain why the sky is blue.', 'Discuss the tradeoffs of wind and solar power.',
             'Explain how a scientist should compare daytime and nighttime temperature.',
             'Describe a practical algorithm for finding the shortest path in a graph.']
    prompts = {i: tokenizer_hf.encode(('A researcher records hourly temperatures. ' * repeat) + text,
               add_special_tokens=False) for i,(text,repeat) in enumerate(zip(texts,[4,32,128,192]),1)}
    assert max(map(len,prompts.values())) + 8 < 4096
    sampling = SamplingParams(
        num_tokens_to_generate=8, temperature=1.0, top_k=1, top_p=0.0,
        add_BOS=False, return_log_probs=True, termination_id=-1,
    )

    measurements = []

    def run(ids, token_budget=4096, chunked=False, stagger=False):
        context = DynamicInferenceContext(
            model_config=base.config,
            inference_config=InferenceConfig(
                max_sequence_length=4096, max_tokens=token_budget, max_requests=8,
                enable_chunked_prefill=chunked,
                buffer_size_gb=2.0, block_size_tokens=64, num_cuda_graphs=None,
                materialize_only_last_token_logits=False,
                use_cuda_graphs_for_non_decode_steps=False, unified_memory_level=0,
            ),
        )
        controller = TextGenerationController(GPTInferenceWrapper(model, context), tokenizer)
        engine = DynamicInferenceEngine(controller=controller, context=context)
        results = {}
        steps = 0
        torch.cuda.synchronize()
        torch.cuda.reset_peak_memory_stats()
        run_start = time.perf_counter()
        with torch.no_grad(), set_batch_invariant_mode(True, backend="te_native"):
            for rid in (ids[:-1] if stagger else ids):
                engine.add_request(rid, prompts[rid], sampling)
            for _ in range(64):
                if not engine.has_unfinished_requests():
                    break
                steps += 1
                if stagger and steps == 2:
                    engine.add_request(ids[-1], prompts[ids[-1]], sampling)
                for req in engine.step_modern()['finished_requests']:
                    results[req.request_id] = {
                        'tokens': req.generated_tokens,
                        'prompt_logprobs': req.prompt_log_probs,
                        'generated_logprobs': req.generated_log_probs,
                    }
            assert not engine.has_unfinished_requests(), 'Probe exceeded step limit'
        torch.cuda.synchronize()
        measurements.append({'ids': list(ids), 'stagger': stagger, 'seconds': time.perf_counter()-run_start, 'peak_allocated_bytes': torch.cuda.max_memory_allocated()})
        assert set(results) == set(ids)
        del engine, controller, context
        gc.collect()
        return results, steps

    full = {}
    full_steps = {}
    for rid in prompts:
        result, steps = run([rid])
        full.update(result)
        full_steps[rid] = steps
    comparisons = {}
    for repeat in range(3):
      for reverse in (False, True):
          ids = list(reversed(prompts)) if reverse else list(prompts)
          result, steps = run(ids, stagger=True)
          comparisons[f'repeat-{repeat}-mixed-reverse-{reverse}'] = {
              'results': result, 'steps': steps, 'equal': result == full,
          }
  
    report = {
        'scope': 'pretrained Moonlight-16B-A3B BF16 TP1; solo vs normal new request arrival',
        'full': full, 'full_steps': full_steps, 'measurements': measurements, 'comparisons': comparisons,
        'equal': all(c['equal'] for c in comparisons.values()),
    }
    output = Path(os.environ['MEASUREMENT_OUTPUT'])
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(json.dumps(report, indent=2) + '\n')
    print('Exact tokens/logprobs equality:', report['equal'])
    Utils.destroy_model_parallel()



if __name__ == '__main__':
    with set_batch_invariant_mode(True, backend="te_native"):
        main()
